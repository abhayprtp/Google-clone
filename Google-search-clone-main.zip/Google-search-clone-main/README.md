
# Google-search-clone

Fully working fake Google search engine clone using html CSS and JS

![Logo](./images/logo.jpg)


## Demo

https://naemazam.github.io/Google-search-clone/

  
## Screenshots

![App Screenshot](./images/Capture.PNG)

## Video Tutorial 

![Youtube](./images/ab(3).jpg)
[Youtube](https://youtu.be/AQafAU7ZHUs)


    
## Contributing

Contributions are always welcome!
 

[![MIT License](https://img.shields.io/apm/l/atomic-design-ui.svg?)](https://github.com/tterb/atomic-design-ui/blob/master/LICENSEs)
